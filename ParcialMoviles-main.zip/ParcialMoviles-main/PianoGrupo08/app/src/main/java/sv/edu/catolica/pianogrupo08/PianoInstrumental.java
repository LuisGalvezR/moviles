package sv.edu.catolica.pianogrupo08;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

public class PianoInstrumental extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_instrumental);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_infantil, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId()) {
            case R.id.Volver:
                Intent objSVentana = new Intent(PianoInstrumental.this, MainActivity.class);
                startActivity(objSVentana);
                finish();
                return true;
            case R.id.PianoFormal:
                Intent nVentana = new Intent(PianoInstrumental.this, PianoClasico.class);
                startActivity(nVentana);
                finish();
                return true;
            case R.id.PianoInfantil:
                Intent objInstrumental = new Intent(PianoInstrumental.this, PianoInfantil.class);
                startActivity(objInstrumental);
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    //NOTA DO INFANTIL
    public void Do8va(View view) {
        MediaPlayer mp = MediaPlayer.create(this, R.raw.instrumentaldo);
        mp.start();
    }

    public void Do8vaArriba(View view) {
        MediaPlayer mp = MediaPlayer.create(this, R.raw.instrumentaldo2);
        mp.start();
    }

    public void DoSostenido(View view) {
        MediaPlayer mp = MediaPlayer.create(this, R.raw.instrumentaldosos);
        mp.start();
    }

    //NOTA RE INFANTIL
    public void Re8va(View view) {
        MediaPlayer mp = MediaPlayer.create(this, R.raw.instrumentalre);
        mp.start();
    }

    public void ReSostenido(View view) {
        MediaPlayer mp = MediaPlayer.create(this, R.raw.instrumentalresos);
        mp.start();
    }

    //NOTA MI INFANTIL
    public void Mi8va(View view) {
        MediaPlayer mp = MediaPlayer.create(this, R.raw.instrumentalmi);
        mp.start();
    }

    //NOTA FA INFANTIL
    public void Fa8va(View view) {
        MediaPlayer mp = MediaPlayer.create(this, R.raw.instrumentalfa);
        mp.start();
    }

    public void FaSostenido(View view) {
        MediaPlayer mp = MediaPlayer.create(this, R.raw.instrumentalfasos);
        mp.start();
    }

    //NOTA SOL INFANTIL
    public void Sol8va(View view) {
        MediaPlayer mp = MediaPlayer.create(this, R.raw.instrumentalsol);
        mp.start();
    }

    public void SolSostenido(View view) {
        MediaPlayer mp = MediaPlayer.create(this, R.raw.instrumentalsolsos);
        mp.start();
    }

    //NOTA LA INFANTIL
    public void La8va(View view) {
        MediaPlayer mp = MediaPlayer.create(this, R.raw.instrumentalla);
        mp.start();
    }

    public void LaSostenido(View view) {
        MediaPlayer mp = MediaPlayer.create(this, R.raw.instrumentallasos);
        mp.start();
    }

    //NOTA SI INFANTIL
    public void Si8va(View view) {
        MediaPlayer mp = MediaPlayer.create(this, R.raw.instrumentalsi);
        mp.start();
    }
}