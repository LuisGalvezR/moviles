package sv.edu.catolica.pianogrupo08;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private Button btnExit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnExit = findViewById(R.id.btnExit);

        btnExit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_principal,
                menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId()) {
            case R.id.PianoFormal:
                Intent objSVentana = new Intent(MainActivity.this, PianoClasico.class);
                startActivity(objSVentana);
                return true;
            case R.id.PianoInfantil:
                Intent nVentana = new Intent(MainActivity.this, PianoInfantil.class);
                startActivity(nVentana);
                return true;
            case R.id.PianoInstrument:
                Intent objInstrumental = new Intent(MainActivity.this, PianoInstrumental.class);
                startActivity(objInstrumental);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

}