package sv.edu.catolica.pianogrupo08;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

public class PianoInfantil extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_piano_infantil);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_infantil, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId()) {
            case R.id.Volver:
                Intent objSVentana = new Intent(PianoInfantil.this, MainActivity.class);
                startActivity(objSVentana);
                finish();
                return true;
            case R.id.PianoFormal:
                Intent nVentana = new Intent(PianoInfantil.this, PianoClasico.class);
                startActivity(nVentana);
                finish();
                return true;
            case R.id.PianoInstrument:
                Intent objInstrumental = new Intent(PianoInfantil.this, PianoInstrumental.class);
                startActivity(objInstrumental);
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    //NOTA DO INFANTIL
    public void Do8va(View view) {
        MediaPlayer mp = MediaPlayer.create(this, R.raw.junglado);
        mp.start();
    }

    public void Do8vaArriba(View view) {
        MediaPlayer mp = MediaPlayer.create(this, R.raw.junglado2);
        mp.start();
    }

    public void DoSostenido(View view) {
        MediaPlayer mp = MediaPlayer.create(this, R.raw.jungladosos);
        mp.start();
    }

    //NOTA RE INFANTIL
    public void Re8va(View view) {
        MediaPlayer mp = MediaPlayer.create(this, R.raw.junglare);
        mp.start();
    }

    public void ReSostenido(View view) {
        MediaPlayer mp = MediaPlayer.create(this, R.raw.junglaresos);
        mp.start();
    }

    //NOTA MI INFANTIL
    public void Mi8va(View view) {
        MediaPlayer mp = MediaPlayer.create(this, R.raw.junglami);
        mp.start();
    }

    //NOTA FA INFANTIL
    public void Fa8va(View view) {
        MediaPlayer mp = MediaPlayer.create(this, R.raw.junglafa);
        mp.start();
    }

    public void FaSostenido(View view) {
        MediaPlayer mp = MediaPlayer.create(this, R.raw.junglafasos);
        mp.start();
    }

    //NOTA SOL INFANTIL
    public void Sol8va(View view) {
        MediaPlayer mp = MediaPlayer.create(this, R.raw.junglasol);
        mp.start();
    }

    public void SolSostenido(View view) {
        MediaPlayer mp = MediaPlayer.create(this, R.raw.junglasolsos);
        mp.start();
    }

    //NOTA LA INFANTIL
    public void La8va(View view) {
        MediaPlayer mp = MediaPlayer.create(this, R.raw.junglala);
        mp.start();
    }

    public void LaSostenido(View view) {
        MediaPlayer mp = MediaPlayer.create(this, R.raw.junglalasos);
        mp.start();
    }

    //NOTA SI INFANTIL
    public void Si8va(View view) {
        MediaPlayer mp = MediaPlayer.create(this, R.raw.junglasi);
        mp.start();
    }
}