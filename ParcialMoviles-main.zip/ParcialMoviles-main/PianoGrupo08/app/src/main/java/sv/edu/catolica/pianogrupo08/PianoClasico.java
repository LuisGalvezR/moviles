package sv.edu.catolica.pianogrupo08;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;

public class PianoClasico extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_clasico);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_clasico, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId()) {
            case R.id.Volver:
                Intent objSVentana = new Intent(PianoClasico.this, MainActivity.class);
                startActivity(objSVentana);
                finish();
                return true;
            case R.id.PianoInfantil:
                Intent nVentana = new Intent(PianoClasico.this, PianoInfantil.class);
                startActivity(nVentana);
                finish();
                return true;
            case R.id.PianoInstrument:
                Intent objInstrumental = new Intent(PianoClasico.this, PianoInstrumental.class);
                startActivity(objInstrumental);
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    //NOTA DO CLASICO
    public void Do8va(View view) {
        MediaPlayer mp = MediaPlayer.create(this, R.raw.clasicodo);
        mp.start();
    }

    public void Do8vaArriba(View view) {
        MediaPlayer mp = MediaPlayer.create(this, R.raw.clasicodo2);
        mp.start();
    }

    public void DoSostenido(View view) {
        MediaPlayer mp = MediaPlayer.create(this, R.raw.clasicodosos);
        mp.start();
    }

    //NOTA RE CLASICO
    public void Re8va(View view) {
        MediaPlayer mp = MediaPlayer.create(this, R.raw.clasicore);
        mp.start();
    }

    public void ReSostenido(View view) {
        MediaPlayer mp = MediaPlayer.create(this, R.raw.clasicoresos);
        mp.start();
    }

    //NOTA MI CLASICO
    public void Mi8va(View view) {
        MediaPlayer mp = MediaPlayer.create(this, R.raw.clasicomi);
        mp.start();
    }

    //NOTA FA CLASICO
    public void Fa8va(View view) {
        MediaPlayer mp = MediaPlayer.create(this, R.raw.clasicofa);
        mp.start();
    }

    public void FaSostenido(View view) {
        MediaPlayer mp = MediaPlayer.create(this, R.raw.clasicofasos);
        mp.start();
    }

    //NOTA SOL CLASICO
    public void Sol8va(View view) {
        MediaPlayer mp = MediaPlayer.create(this, R.raw.clasicosol);
        mp.start();
    }

    public void SolSostenido(View view) {
        MediaPlayer mp = MediaPlayer.create(this, R.raw.clasicosolsos);
        mp.start();
    }

    //NOTA LA CLASICO
    public void La8va(View view) {
        MediaPlayer mp = MediaPlayer.create(this, R.raw.clasicola);
        mp.start();
    }

    public void LaSostenido(View view) {
        MediaPlayer mp = MediaPlayer.create(this, R.raw.clasicolasos);
        mp.start();
    }

    //NOTA SI CLASICO
    public void Si8va(View view) {
        MediaPlayer mp = MediaPlayer.create(this, R.raw.clasicosi);
        mp.start();
    }
}